package cn.edu.seu.bussiness;

import cn.edu.seu.dao.DB_Manager;
import cn.edu.seu.model.Order;
import cn.edu.seu.model.OrderContent;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Statistics {
    public static List<Order> getHistoryLists(
            String beginTime,
            String endTime
    ){
        List<Order> orderList = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        Date begin = null;
        Date end = null;

        try {
            begin = sdf.parse(beginTime);
            end = sdf.parse(endTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        try {
            for(Object o : DB_Manager.FindAll("Order")){
                if(((Order)o).getBeginTime().after(begin) &&
                        ((Order)o).getBeginTime().before(end)){
                    orderList.add((Order)o);
                    System.out.println((Order)o);
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("getHistoryLists" + orderList);

        return orderList;
    }

    public static Date dayBefore(Date date){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int day = calendar.get(Calendar.DATE);
        calendar.set(Calendar.DATE, day - 1);

        return calendar.getTime();
    }

    public static Date weekBefore(Date date){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int week = calendar.get(Calendar.WEEK_OF_YEAR);
        calendar.set(Calendar.WEEK_OF_YEAR, week - 1);

        return calendar.getTime();
    }

    public static Date monthBefore(Date date){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int month = calendar.get(Calendar.MONTH);
        calendar.set(Calendar.MONTH, month - 1);

        return calendar.getTime();
    }

    public static List<Integer> getDayCounts() {
        Date date = new Date();

        return orderCounts(dayBefore(date), date);
    }

    public static List<Integer> getWeekCounts() {
        Date date = new Date();

        return orderCounts(weekBefore(date), date);
    }

    public static List<Integer> getMonthCounts() {
        Date date = new Date();

        return orderCounts(monthBefore(date), date);
    }


    public static Double getDaySum(){
        Date date = new Date();

        return sales(dayBefore(date), date);
    }

    public static Double getWeekSum(){
        Date date = new Date();

        return sales(weekBefore(date), date);
    }

    public static Double getMonthSum(){
        Date date = new Date();

        return sales(monthBefore(date), date);
    }

    private static List<Integer> orderCounts(Date begin, Date end) {
        ArrayList<Integer> counts = new ArrayList<>();

        try {
            for (Object ob : DB_Manager.FindAll("Order")) {
                Order order = (Order) ob;
                if (order.getBeginTime().after(begin) && order.getBeginTime().before(end)) {
                    int i = order.getBeginTime().getHours();
                    counts.set(i, counts.get(i) + 1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return counts;
    }

    private static Double sales(Date begin, Date end) {
        Double sum = 0d;

        try {
            for (Object ob : DB_Manager.FindAll("Order")) {
                Order order = (Order) ob;
                if (order.getBeginTime().after(begin) && order.getBeginTime().before(end)) {
                    for (OrderContent orderContent : order.getFood()) {
                        sum += (orderContent.getDisNumber() * orderContent.getDishId().getPrice());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return sum;
    }
}
