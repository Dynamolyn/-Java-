package cn.edu.seu.model;

public class Model {
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Model(int id) {
        this.id = id;
    }

    public Model() {}
}
