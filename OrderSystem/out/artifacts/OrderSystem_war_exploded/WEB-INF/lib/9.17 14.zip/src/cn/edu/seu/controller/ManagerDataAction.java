package cn.edu.seu.controller;

import cn.edu.seu.bussiness.ModifyOrder;
import cn.edu.seu.bussiness.Statistics;
import cn.edu.seu.model.Order;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

@Controller
public class ManagerDataAction {
    @RequestMapping(value = "/searchOrderData.do",method = RequestMethod.POST)
    public void searchOrderData(HttpServletRequest request, HttpServletResponse response){
        List<Order> orderList = Statistics.getHistoryLists(request.getParameter("beginData"),request.getParameter("endData"));
        System.out.println("ManagerDataAction" + orderList);
        List<OrderInfo> orderInfoList =  new ArrayList<>();
        OrderInfo orderInfo;
        DecimalFormat df = new DecimalFormat("#.00");
        for(Order order:orderList){
            System.out.println("order : " + order);
            orderInfo = new OrderInfo();
            orderInfo.setId(order.getId());
            System.out.println("id");
            orderInfo.setTableId(order.getTableId());
            System.out.println("table id : ");
            orderInfo.setBeginTime(order.getBeginTime().toString());
            System.out.println("beginTime : ");
            Double price  = Double.parseDouble(df.format(ModifyOrder.getHistorySum(order.getId())));
            orderInfo.setSelePrice(price);
            System.out.println("price : ");
            orderInfoList.add(orderInfo);

            System.out.println("orderINfo : ");
            System.out.println(orderInfo);
        }
        try {
            PrintWriter p = response.getWriter();
            System.out.println("Json" + DataFactory.documentToJson(orderInfoList));
            if(DataFactory.documentToJson(orderInfoList).isEmpty())
                p.write("null");
            else
            p.write(DataFactory.documentToJson(orderInfoList));
            p.flush();
            p.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
